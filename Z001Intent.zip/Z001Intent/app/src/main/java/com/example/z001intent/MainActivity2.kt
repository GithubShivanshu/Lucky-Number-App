package com.example.z001intent

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.w3c.dom.Text
import kotlin.random.Random
import kotlin.random.Random as Random1

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val vmessage=intent.getStringExtra("xyz")
        val guess=intent.getStringExtra("xyzzz")

        val vtextview=findViewById<TextView>(R.id.textView2).apply { text=vmessage }
        val cc=findViewById<TextView>(R.id.textView4).apply { text=guess }

        val shareBtn=findViewById<Button>(R.id.button2)as TextView

        val luckyNumber=findViewById<TextView>(R.id.textView)as TextView

        val randomNumber = generateRandomNumber()
        luckyNumber.text = randomNumber.toString()

        shareBtn.setOnClickListener {
            shareData(vmessage, randomNumber)
        }

    }
    private fun generateRandomNumber(): Int {
        val random = Random
        val upperLimit = 1000
        return random.nextInt(upperLimit)
    }

    private fun shareData(username: String?, randomNumber: Int) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
//        i.putExtra(Intent.EXTRA_SUBJECT, "$username got lucky today!")
        i.putExtra(Intent.EXTRA_TEXT, username+"'s lucky number is $randomNumber")
        startActivity(Intent.createChooser(i, "Choose a platform"))
    }
}