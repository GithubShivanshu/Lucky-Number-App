package com.example.z001intent

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val vbutton=findViewById<Button>(R.id.button)as Button

        vbutton.setOnClickListener()
        {
            callActivity()
        }
    }
    private fun callActivity(){
        val vedittext=findViewById<EditText>(R.id.edit_text)as EditText
        val vmessage=vedittext.text.toString()

        val vedit=findViewById<EditText>(R.id.editTextText)as EditText
        val vint=vedit.text.toString()

        val vintent=Intent(this,MainActivity2::class.java).also{
            it.putExtra("xyz",vmessage)
            it.putExtra("xyzzz",vint)
            startActivity(it)
        }
    }
}


